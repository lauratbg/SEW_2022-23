package main;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import file.FileUtil;

public class WMLtoHTML5 {

	private String archivoWML;
	private String archivoHTML5;

	public WMLtoHTML5(String archivoWML, String archivoHTML5) {
		this.archivoWML = archivoWML;
		this.archivoHTML5 = archivoHTML5;
	}

	private List<QueryInfo> query = new ArrayList<>();
	private List<SourceInfo> informacion = new ArrayList<>();
	private List<Variable> variables = new ArrayList<>();
	private List<Values> valuesl = new ArrayList<>();


	public void crearHTML5() throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		inicio();
		parse();
		cuerpo();
		escribirArchivo();
	}

	private void inicio() {
		lineas.add("<!DOCTYPE HTML>\r\n" + "\r\n" + "<html lang=\"es\">\r\n" + "<head>\r\n"
				+ "    <!-- Datos que describen el documento -->\r\n" + "    <meta charset=\"UTF-8\" />\r\n"
				+ "    <title>WaterML</title>\r\n" + "\r\n" + "     <!-- Autor -->\r\n"
				+ "    <meta name =\"author\" content =\"Laura Gómez\" />\r\n" + "\r\n" + "    <!-- Descripción -->\r\n"
				+ "    <meta name =\"description\" content =\"WaterML\" />\r\n" + "\r\n"
				+ "    <!-- Palabras clave -->\r\n" + "    <meta name =\"keywords\" content =\"WaterML\" />\r\n"
				+ "\r\n" + "    <!-- Definir la ventana gráfica -->\r\n"
				+ "    <meta name =\"viewport\" content =\"width=device-width, initial-scale=1.0\" />\r\n" + "\r\n"
				+ "    <!-- añadir el elemento link de enlace a la hoja de estilo dentro del <head> del documento html -->\r\n"
				+ "    <link rel=\"stylesheet\" type=\"text/css\" href=\"estilo/estilo.css\" />\r\n" + "\r\n"
				+ "</head>");
	}

	public void parse() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		FileInputStream XML = new FileInputStream("src/" + archivoWML);
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = builderFactory.newDocumentBuilder();
		Document xmlDocument = builder.parse(XML);
		XPath xPath = XPathFactory.newInstance().newXPath();

		NodeList nodelist0 = (NodeList) xPath.compile("//queryInfo").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int h = 0; h < nodelist0.getLength(); h++) {
			Node nodo0 = nodelist0.item(h);
			QueryInfo q = new QueryInfo();

			q.tiempoCreacion = xPath.compile("creationTime").evaluate(nodo0);
			query.add(q);
		}

		NodeList nodelist = (NodeList) xPath.compile("//sourceInfo").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodelist.getLength(); i++) {
			Node nodo = nodelist.item(i);

			SourceInfo p = new SourceInfo();
			p.nombre = xPath.compile("siteName").evaluate(nodo);
			p.elevation_m = xPath.compile("elevation_m").evaluate(nodo);
			p.verticalDatum = xPath.compile("verticalDatum").evaluate(nodo);

			NodeList nodelist2 = (NodeList) xPath.compile("geoLocation").evaluate(nodo, XPathConstants.NODESET);
			for (int j = 0; j < nodelist2.getLength(); j++) {
				Node nodo2 = nodelist2.item(j);

				Node coord = (Node) xPath.compile("geogLocation").evaluate(nodo2, XPathConstants.NODE);
				p.geogLocation.latitud = xPath.compile("latitude").evaluate(coord);
				p.geogLocation.longitud = xPath.compile("longitude").evaluate(coord);

				Node xy = (Node) xPath.compile("localSiteXY").evaluate(nodo2, XPathConstants.NODE);
				p.localSiteXY.x = xPath.compile("X").evaluate(xy);
				p.localSiteXY.y = xPath.compile("Y").evaluate(xy);
			}

			informacion.add(p);
		}
		NodeList nodelistV = (NodeList) xPath.compile("//variable").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodelistV.getLength(); i++) {
			Node nodo = nodelistV.item(i);

			Variable v = new Variable();
			v.variableNombre = xPath.compile("variableName").evaluate(nodo);
			v.tipo = xPath.compile("valueType").evaluate(nodo);
			v.dataType = xPath.compile("dataType").evaluate(nodo);
			v.categoriaGeneral = xPath.compile("generalCategory").evaluate(nodo);
			v.medioDeMuestra = xPath.compile("sampleMedium").evaluate(nodo);
			v.valorSinDato = xPath.compile("noDataValue").evaluate(nodo);
			v.especiacion = xPath.compile("speciation").evaluate(nodo);

			Node coord = (Node) xPath.compile("unit").evaluate(nodo, XPathConstants.NODE);
			v.unidad.unitNombre = xPath.compile("unitName").evaluate(coord);
			v.unidad.tipo = xPath.compile("unitType").evaluate(coord);
			v.unidad.abreviacion = xPath.compile("unitAbbreviation").evaluate(coord);
			v.unidad.codigo = xPath.compile("unitCode").evaluate(coord);

			variables.add(v);
		}

		NodeList nodelistValues = (NodeList) xPath.compile("//values").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodelistValues.getLength(); i++) {
			Node nodo = nodelistValues.item(i);
			Values values = new Values();
			
			values.value= xPath.compile("value").evaluate(nodo);
			
			Node quality = (Node) xPath.compile("qualityControlLevel").evaluate(nodo, XPathConstants.NODE);
			values.nivelDeControlDeCalidad.codigo= xPath.compile("qualityControlLevelCode").evaluate(quality);
			values.nivelDeControlDeCalidad.definicion= xPath.compile("definition").evaluate(quality);
			values.nivelDeControlDeCalidad.explicacion= xPath.compile("explanation").evaluate(quality);

			Node method = (Node) xPath.compile("method").evaluate(nodo, XPathConstants.NODE);
			values.metodo.codigo= xPath.compile("methodCode").evaluate(method);
			values.metodo.descripcion= xPath.compile("methodDescription").evaluate(method);

			Node source = (Node) xPath.compile("source").evaluate(nodo, XPathConstants.NODE);
			values.source.codigo= xPath.compile("sourceCode").evaluate(source);
			values.source.organizacion= xPath.compile("organization").evaluate(source);
			
			Node contactInformation = (Node) xPath.compile("contactInformation").evaluate(source, XPathConstants.NODE);
			values.source.informacionContacto.nombre= xPath.compile("contactName").evaluate(contactInformation);
			values.source.informacionContacto.tipoDeContacto= xPath.compile("typeOfContact").evaluate(contactInformation);
			values.source.informacionContacto.email= xPath.compile("email").evaluate(contactInformation);
			values.source.informacionContacto.telefono= xPath.compile("phone").evaluate(contactInformation);
			values.source.sourceLink= xPath.compile("sourceLink").evaluate(source);
			values.source.citation= xPath.compile("citation").evaluate(source);
			
			Node sample = (Node) xPath.compile("sample").evaluate(nodo, XPathConstants.NODE);
			values.sample.codigo= xPath.compile("labSampleCode").evaluate(sample);
			values.sample.tipo= xPath.compile("sampleType").evaluate(sample);
			Node lab = (Node) xPath.compile("labMethod").evaluate(sample, XPathConstants.NODE);
			values.sample.lab.codigo = xPath.compile("labCode").evaluate(lab);
			values.sample.lab.nombre = xPath.compile("labName").evaluate(lab);
			values.sample.lab.organizacion = xPath.compile("labOrganization").evaluate(lab);
			values.sample.lab.nombreMetodo = xPath.compile("labMethodName").evaluate(lab);

			valuesl.add(values);


		}
	}

	private void cuerpo() {
		lineas.add("<body>");

		lineas.add("<h1>WaterML</h1>");

		for (QueryInfo q : query) {
			lineas.add("<p>Tiempo de creación: " + q.tiempoCreacion + "</p>");
		}
		for (SourceInfo p : informacion) {
			lineas.add("<h2>" + p.nombre + "</h2>");
			lineas.add("<p>Elevación: " + p.elevation_m + "</p>");
			lineas.add("<p>Vertical Datum: " + p.verticalDatum + "</p>");

			lineas.add("<p>Localización geográfica<p>");
			p.geogLocation.toHTML5();
			lineas.add("<p>X Y<p>");
			p.localSiteXY.toHTML5();
		}

		for (Variable p : variables) {
			lineas.add("<h3> Variable: " + p.variableNombre + "</h3>");
			lineas.add("<p>Tipo: " + p.tipo + "</p>");
			lineas.add("<p>Tipo de dato: " + p.dataType + "</p>");
			lineas.add("<p>Categoría General: " + p.categoriaGeneral + "</p>");
			lineas.add("<p>Medio de muestra: " + p.medioDeMuestra + "</p>");
			lineas.add("<p>Sin valor de datos: " + p.valorSinDato + "</p>");
			lineas.add("<p>Especiación: " + p.especiacion + "</p>");

			lineas.add("<p>Unidad<p>");
			p.unidad.toHTML5();
		}

		for(Values p:valuesl) {
			lineas.add("<h3> Valor: " + p.value + "</h3>");
			lineas.add("<p>Nivel de control de calidad<p>");
			p.nivelDeControlDeCalidad.toHTML5();
			lineas.add("<p>Método<p>");
			p.metodo.toHTML5();
			lineas.add("<p>Fuente<p>");
			p.source.toHTML5();

			lineas.add("<p>Muestra<p>");
			p.sample.toHTML5();
		
			
		}
		lineas.add("</body>");
		lineas.add("</html>");

	}

	private FileUtil f = new FileUtil();

	public void escribirArchivo() {
		f.writeLines(archivoHTML5, lineas);
	}

	private List<String> lineas = new ArrayList<>();

	public class QueryInfo {
		String tiempoCreacion;
	}

	public class SourceInfo {
		String nombre;
		Coordenadas geogLocation = new Coordenadas();
		LocalSite localSiteXY = new LocalSite();
		String elevation_m;
		String verticalDatum;

	}

	public class Coordenadas {
		String latitud;
		String longitud;

		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Longitud: " + longitud + "</li>");
			lineas.add("<li> Latitud: " + latitud + "</li>");
			lineas.add("</ul>");
		}
	}

	public class LocalSite {
		String x;
		String y;

		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> X: " + x + "</li>");
			lineas.add("<li> Y: " + y + "</li>");
			lineas.add("</ul>");
		}
	}

	public class Variable {
		String variableNombre;
		String tipo;
		String dataType;
		String categoriaGeneral;
		String medioDeMuestra;
		Unit unidad = new Unit();
		String valorSinDato;
		String especiacion;;
	}

	public class Unit {
		String unitNombre;
		String tipo;
		String abreviacion;
		String codigo;

		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Nombre: " + unitNombre + "</li>");
			lineas.add("<li> Tipo: " + tipo + "</li>");
			lineas.add("<li> Abreviación: " + abreviacion + "</li>");
			lineas.add("<li> Código: " + codigo + "</li>");
			lineas.add("</ul>");
		}
	}
	
	public class Values {
		String value;
		QualityControlLevel nivelDeControlDeCalidad = new QualityControlLevel();
		Method metodo = new Method();
		Source source = new Source();
		Sample sample = new Sample();
	}
	
	public class QualityControlLevel {
		String codigo;
		String definicion;
		String explicacion;
		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Código: " + codigo + "</li>");
			lineas.add("<li> Definición: " + definicion + "</li>");
			lineas.add("<li> Explicación: " + explicacion + "</li>");
			lineas.add("</ul>");
		}
	}
	
	public class Method{
		String codigo;
		String descripcion;
		
		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Código: " + codigo + "</li>");
			lineas.add("<li> Descripcion: " + descripcion + "</li>");
			lineas.add("</ul>");
		}
	}
	
	public class Source{
		String codigo;
		String organizacion;
		ContactInformation informacionContacto = new ContactInformation();
		String sourceLink;
		String citation;
		
		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Código: " + codigo + "</li>");
			lineas.add("<li> Link: " + sourceLink + "</li>");
			lineas.add("<li> Citación: " + citation + "</li>");
			lineas.add("<li> Información de contacto: " + informacionContacto.toHTML5() + "</li>");
			lineas.add("</ul>");
		}
	}
	
	public class ContactInformation{
		String nombre;
		String tipoDeContacto;
		String email;
		String telefono;
		
		public String toHTML5() {
			return "<ul> "
					+ "<li> Nombre: " + nombre + "</li>"
					+ "<li> Tipo de contacto: " + tipoDeContacto + "</li>"
			+"<li> Email: " + email + "</li>"
			+"<li> Telefono: " + telefono + "</li>"
			+"</ul>";
		}
	}
	
	public class Sample{
		String codigo;
		String tipo;
		Laboratorio lab = new Laboratorio();
		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Código: " + codigo + "</li>");
			lineas.add("<li> Tipo: " + tipo + "</li>");
			lineas.add("<li> Laboratorio: " + lab.toHTML5() + "</li>");
			lineas.add("</ul>");
		}
	}
	
	public class Laboratorio{
		String codigo;
		String nombre;
		String organizacion;
		String nombreMetodo;
		public String toHTML5() {
			return "<ul> " 
			+"<li> Código: " + codigo + "</li>"
			+"<li> Nombre: " + nombre + "</li>"
			+"<li> Organizacion: " + organizacion + "</li>"
			+"<li> Nombre del método: " + nombreMetodo + "</li>"
			+"</ul>";
		}
	}

}
