package main;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

public class Main {
	public static void main(String[] args) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		WMLtoHTML5 execute = new WMLtoHTML5("archivo.xml","archivo.html");
		execute.crearHTML5();
	}
}
