package file;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil extends BasicFileUtil {
	@Override
	public BufferedReader openForReading(String filename) throws FileNotFoundException {
		 return new BufferedReader(new FileReader(filename));
	}

	@Override
	public BufferedWriter openForWriting(String filename) throws IOException {
		return new BufferedWriter(new FileWriter(filename));
	}
}

