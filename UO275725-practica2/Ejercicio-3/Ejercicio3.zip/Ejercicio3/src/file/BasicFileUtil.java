package file;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public abstract class BasicFileUtil {
	protected abstract BufferedReader openForReading(String filename) throws FileNotFoundException;

	protected abstract BufferedWriter openForWriting(String filename) throws IOException;

	public List<String> readLines(String inFileName) throws FileNotFoundException {
		List<String> res = new LinkedList<>();

		BufferedReader reader = openForReading(inFileName);

		try {
			try {
				String line;
				while ((line = reader.readLine()) != null) {
					res.add(line);
				}
			} finally {
				reader.close();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return res;
	}

	public void writeLines(String outFileName, List<String> lines) { 
		try {
			BufferedWriter writer = openForWriting(outFileName);
			try {
				for(String line : lines) {
					writer.write(line);
					writer.newLine();
				}
			} finally {
				writer.close();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}

