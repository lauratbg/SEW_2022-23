package main;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import file.FileUtil;

public class XMLtoSVG {

	private String archivoXML;
	private String archivoSVG;

	public XMLtoSVG(String archivoXML, String archivoSVG) {
		this.archivoXML = archivoXML;
		this.archivoSVG = archivoSVG;
	}

	public void crearSVG() throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		inicio();
		parse();
		arbol();
		informacion();
		camino();
		escribirArchivo();
	}

	private List<String> lineas = new ArrayList<>();

	private void inicio() {
		lineas.add("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n"
				+ "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" >");
	}

	private List<Persona> personas = new ArrayList<>();

	public void parse() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		FileInputStream xml = new FileInputStream("src/" + archivoXML);
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = builderFactory.newDocumentBuilder();
		Document xmlDocument = builder.parse(xml);
		XPath xPath = XPathFactory.newInstance().newXPath();

		NodeList nodeList = (NodeList) xPath.compile("//persona").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node nodo = nodeList.item(i);

			Persona p = new Persona();
			p.nombre = xPath.compile("@nombre").evaluate(nodo);
			p.apellidos = xPath.compile("@apellidos").evaluate(nodo);
			p.fechaNacimiento = xPath.compile("@fechaNacimiento").evaluate(nodo);
			p.lugarNacimiento = xPath.compile("@lugarNacimiento").evaluate(nodo);
			p.lugarResidencia = xPath.compile("@lugarResidencia").evaluate(nodo);
			p.comentario = xPath.compile("@comentarios").evaluate(nodo);
			
			Node nacimientocoord = (Node) xPath.compile("coordenadasNacimiento").evaluate(nodo, XPathConstants.NODE);
			p.coordenadasNacimiento.latitud  = xPath.compile("@latitud").evaluate(nacimientocoord);
			p.coordenadasNacimiento.longitud = xPath.compile("@longitud").evaluate(nacimientocoord);
			p.coordenadasNacimiento.altitud = xPath.compile("@altitud").evaluate(nacimientocoord);
			
			Node lugarResidenciaCoord = (Node) xPath.compile("coordenadasResidencia").evaluate(nodo, XPathConstants.NODE);
			p.coordenadasResidencia.latitud = xPath.compile("@latitud").evaluate(lugarResidenciaCoord);
			p.coordenadasResidencia.longitud = xPath.compile("@longitud").evaluate(lugarResidenciaCoord);
			p.coordenadasResidencia.altitud = xPath.compile("@altitud").evaluate(lugarResidenciaCoord);
			
			NodeList fotos = (NodeList) xPath.compile("foto").evaluate(nodo, XPathConstants.NODESET);
			NodeList videos = (NodeList) xPath.compile("video").evaluate(nodo, XPathConstants.NODESET);

			Node nodo2;
			for (int j = 0; j < fotos.getLength(); j++) {
				nodo2 = fotos.item(j);
				if (nodo2.getFirstChild() != null)
					p.fotos.add(nodo2.getFirstChild().getNodeValue());
			}

			for (int j = 0; j < videos.getLength(); j++) {
				nodo2 = videos.item(j);
				if (nodo2.getFirstChild() != null)
					p.videos.add(nodo2.getFirstChild().getNodeValue());
			}

			personas.add(p);
		}

	}

	private void arbol() {
		personas.get(0).altura = 1;
		personas.get(0).i = 1;
		personas.get(0).amigos = true;

		personas.get(1).altura = 2;
		personas.get(1).i = 2;
		personas.get(1).amigos = true;

		personas.get(2).altura = 3;
		personas.get(2).i = 3;
		personas.get(2).amigos = false;

		personas.get(3).altura = 3;
		personas.get(3).i = 4;
		personas.get(3).amigos = false;

		personas.get(4).altura = 3;
		personas.get(4).i = 5;
		personas.get(4).amigos = false;

		personas.get(5).altura = 2;
		personas.get(5).i = 6;
		personas.get(5).amigos = true;

		personas.get(6).altura = 3;
		personas.get(6).i = 7;
		personas.get(6).amigos = false;

		personas.get(7).altura = 3;
		personas.get(7).i = 8;
		personas.get(7).amigos = false;

		personas.get(8).altura = 3;
		personas.get(8).i = 9;
		personas.get(8).amigos = false;

		personas.get(9).altura = 2;
		personas.get(9).i = 10;
		personas.get(9).amigos = true;

		personas.get(10).altura = 3;
		personas.get(10).i = 11;
		personas.get(10).amigos = false;

		personas.get(11).altura = 3;
		personas.get(11).i = 12;
		personas.get(11).amigos = false;

		personas.get(12).altura = 3;
		personas.get(12).i = 13;
		personas.get(12).amigos = false;
	}

	private final int ancho = 400;
	private final int alto = 43;
	private final int paddingX = 5;
	private final int paddingY = 5;

	private void informacion() {

		for (Persona p : personas) {
			int x = (p.altura - 1) * (ancho + paddingY) + paddingX;
			int y = (p.i - 1) * (alto + paddingX) + paddingX;

			lineas.add("<rect x=\"" + x + "\" y=\"" + y + "\" width=\"" + ancho + "\" height=\"" + alto
					+ "\" style=\"fill:yellow;stroke:purple;stroke-width:1\"/>");
			x += 10;
			y += 10;
			lineas.add("<text x=\"" + x + "\" y=\"" + y + "\" font-size=\"9\" style=\"fill:black\">" + p.nombre + " "
					+ p.apellidos + "</text>");
			y += 10;
			lineas.add("<text x=\"" + x + "\" y=\"" + y + "\" font-size=\"8\" style=\"fill:black\">"
					+ "\n Nacimiento - " + p.lugarNacimiento + " - " + p.coordenadasNacimiento + " el " + p.fechaNacimiento + "</text>");
			y += 10;
			lineas.add("<text x=\"" + x + "\" y=\"" + y + "\" font-size=\"8\" style=\"fill:black\">"
					+ "\n Residencia - " + p.lugarResidencia + " - " + p.coordenadasResidencia + "</text>");
			y += 10;
			lineas.add("<text x=\"" + x + "\" y=\"" + y + "\" font-size=\"8\" style=\"fill:black\">"
					+ "\n Comentario - "+ p.comentario + " - Fotos - " + p.fotos + ", videos - " + p.videos + "</text>");
		}
	}

	private void camino() {
		for (Persona p : personas) {
			if (p.amigos) {
				String camino = "<path d=\"";
				int x = (p.altura - 1) * (ancho + paddingY) + paddingX + ancho;
				int y = (p.i - 1) * (alto + paddingX) + paddingX + alto / 2;

				if (p.altura == 1) {
					camino += "M " + x + " " + y + " L " + ((ancho + paddingY) + paddingX) + " "
							+ ((1) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + ((ancho + paddingY) + paddingX) + " "
							+ ((5) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + ((ancho + paddingY) + paddingX) + " "
							+ ((9) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
				}
				
				if (p.altura == 2 && p.i == 2) {
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((2) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((3) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((4) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
				}

				if (p.altura == 2 && p.i == 6) {
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((6) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((7) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((8) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
				}

				if (p.altura == 2 && p.i == 10) {
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((10) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((11) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\";stroke:black\"/>" + "\n";
					camino += "<path d=\"";
					camino += "M " + x + " " + y + " L " + (2 * (ancho + paddingY) + paddingX) + " "
							+ ((12) * (alto + paddingX) + paddingX) + " m " + 0 + " " + 0 + " z\"";
					camino += " style=\"stroke:black\"/>" + "\n";
				}
				lineas.add(camino);
			}
		}
		lineas.add("</svg>");
	}

	private FileUtil f = new FileUtil();

	public void escribirArchivo() {
		f.writeLines(archivoSVG, lineas);
	}

	public class Persona {
		String nombre;
		String apellidos;
		String fechaNacimiento;
		String lugarNacimiento;
		String lugarResidencia;
		String comentario;
		
		Coordenadas coordenadasNacimiento =new Coordenadas();
		Coordenadas coordenadasResidencia =new Coordenadas();

		List<String> fotos = new ArrayList<String>();
		List<String> videos = new ArrayList<String>();

		int altura;
		int i;
		boolean amigos;

	}
	
	public class Coordenadas {
		String latitud;
		String longitud;
		String altitud;

		public String toString() {
			return "Longitud: " + longitud + ", latitud: " + latitud + ", altitud: " + altitud;
		}
	}

}
