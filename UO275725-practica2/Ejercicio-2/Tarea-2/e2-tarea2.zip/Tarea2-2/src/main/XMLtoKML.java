package main;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import file.FileUtil;

public class XMLtoKML {

	private String archivoXML;
	private String archivoKML;

	public XMLtoKML(String archivoXML, String archivoKML) {
		this.archivoXML = archivoXML;
		this.archivoKML = archivoKML;
	}

	private List<Lugar> lugares = new ArrayList<>();

	public void crearKML() throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		inicio();
		parse();
		marcarLugar();
		escribirArchivo();
	}

	private List<String> lineas = new ArrayList<>();

	private void inicio() {
		lineas.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		lineas.add("<kml xmlns=\"http://www.opengis.net/kml/2.2\">");
	}

	public void parse() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		FileInputStream xml = new FileInputStream("src/" + archivoXML);
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = builderFactory.newDocumentBuilder();
		Document xmlDocument = builder.parse(xml);
		XPath xPath = XPathFactory.newInstance().newXPath();

		NodeList nodeList = (NodeList) xPath.compile("//persona").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node nodo = nodeList.item(i);

			Lugar lugar = new Lugar();
			lugar.nombre = xPath.compile("@nombre").evaluate(nodo);
			lugar.apellidos = xPath.compile("@apellidos").evaluate(nodo);

			Node nacimientoCoord = (Node) xPath.compile("coordenadasNacimiento").evaluate(nodo, XPathConstants.NODE);
			lugar.coordenadasNacimiento.altitud = Double.valueOf(xPath.compile("@altitud").evaluate(nacimientoCoord));
			lugar.coordenadasNacimiento.latitud = Double.valueOf(xPath.compile("@latitud").evaluate(nacimientoCoord));
			lugar.coordenadasNacimiento.longitud = Double.valueOf(xPath.compile("@longitud").evaluate(nacimientoCoord));

			Node residenciaCoord = (Node) xPath.compile("coordenadasResidencia").evaluate(nodo, XPathConstants.NODE);
			lugar.coordenadasResidencia.altitud = Double.valueOf(xPath.compile("@altitud").evaluate(residenciaCoord));
			lugar.coordenadasResidencia.latitud = Double.valueOf(xPath.compile("@latitud").evaluate(residenciaCoord));
			lugar.coordenadasResidencia.longitud = Double.valueOf(xPath.compile("@longitud").evaluate(residenciaCoord));

			lugares.add(lugar);
		}

	}

	private void marcarLugar() {
		lineas.add("<Document>");

		for (Lugar p : lugares) {
			lineas.add("<Placemark>");
			lineas.add(String.format("<name>" + p.nombre + " " + p.apellidos + " - Nacimiento </name>"));
			lineas.add("<Point>");
			lineas.add(String.format("<coordinates>" + p.coordenadasNacimiento.longitud + " "
					+ p.coordenadasNacimiento.latitud + " " + p.coordenadasNacimiento.altitud + "</coordinates>"));
			lineas.add("</Point>");
			lineas.add("</Placemark>");

			lineas.add("<Placemark>");
			lineas.add(String.format("<name>" + p.nombre + " " + p.apellidos + " - Residencia </name>"));
			lineas.add("<Point>");
			lineas.add(String.format("<coordinates>" + p.coordenadasResidencia.longitud + " "
					+ p.coordenadasResidencia.latitud + " " + p.coordenadasResidencia.altitud + "</coordinates>"));
			lineas.add("</Point>");
			lineas.add("</Placemark>");
		}

		lineas.add("</Document>");
		lineas.add("</kml>");
	}

	private FileUtil f = new FileUtil();

	public void escribirArchivo() {
		f.writeLines(archivoKML, lineas);
	}

	public class Lugar {
		String nombre;
		String apellidos;
		String lugarNacimiento;
		String lugarResidencia;
		Coordenadas coordenadasNacimiento = new Coordenadas();
		Coordenadas coordenadasResidencia = new Coordenadas();
	}

	public class Coordenadas {
		Double latitud;
		Double longitud;
		Double altitud;
	}

}
