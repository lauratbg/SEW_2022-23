package main;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import file.FileUtil;

public class XMLtoHTML5 {

	private String archivoXML;
	private String archivoHTML5;

	public XMLtoHTML5(String archivoXML, String archivoHTML5) {
		this.archivoXML = archivoXML;
		this.archivoHTML5 = archivoHTML5;
	}

	private List<Persona> personas = new ArrayList<>();

	public void crearHTML5() throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		inicio();
		parse();
		cuerpo();
		escribirArchivo();
	}

	private void inicio() {
		lineas.add("<!DOCTYPE HTML>\r\n"
				+ "\r\n"
				+ "<html lang=\"es\">\r\n"
				+ "<head>\r\n"
				+ "    <!-- Datos que describen el documento -->\r\n"
				+ "    <meta charset=\"UTF-8\" />\r\n"
				+ "    <title>Red social</title>\r\n"
				+ "\r\n"
				+ "     <!-- Autor -->\r\n"
				+ "    <meta name =\"author\" content =\"Laura Gómez\" />\r\n"
				+ "\r\n"
				+ "    <!-- Descripción -->\r\n"
				+ "    <meta name =\"description\" content =\"Red social\" />\r\n"
				+ "\r\n"
				+ "    <!-- Palabras clave -->\r\n"
				+ "    <meta name =\"keywords\" content =\"red social, persona, nombre\" />\r\n"
				+ "\r\n"
				+ "    <!-- Definir la ventana gráfica -->\r\n"
				+ "    <meta name =\"viewport\" content =\"width=device-width, initial-scale=1.0\" />\r\n"
				+ "\r\n"
				+ "    <!-- añadir el elemento link de enlace a la hoja de estilo dentro del <head> del documento html -->\r\n"
				+ "    <link rel=\"stylesheet\" type=\"text/css\" href=\"estilo/estilo.css\" />\r\n"
				+ "\r\n"
				+ "</head>");
	}
	
	public void parse() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		FileInputStream XML = new FileInputStream("src/" + archivoXML);
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = builderFactory.newDocumentBuilder();
		Document xmlDocument = builder.parse(XML);
		XPath xPath = XPathFactory.newInstance().newXPath();

		NodeList nodelist = (NodeList) xPath.compile("//persona").evaluate(xmlDocument, XPathConstants.NODESET);
		for (int i = 0; i < nodelist.getLength(); i++) {
			Node nodo = nodelist.item(i);

			Persona p = new Persona();
			p.nombre = xPath.compile("@nombre").evaluate(nodo);
			p.apellidos = xPath.compile("@apellidos").evaluate(nodo);
			p.fechaNacimiento = xPath.compile("@fechaNacimiento").evaluate(nodo);
			p.lugarNacimiento = xPath.compile("@lugarNacimiento").evaluate(nodo);
			p.lugarResidencia = xPath.compile("@lugarResidencia").evaluate(nodo);
			p.comentario = xPath.compile("@comentarios").evaluate(nodo);

			Node nacimientocoord = (Node) xPath.compile("coordenadasNacimiento").evaluate(nodo, XPathConstants.NODE);
			p.lugarNacimientoCoord.latitud  = xPath.compile("@latitud").evaluate(nacimientocoord);
			p.lugarNacimientoCoord.longitud = xPath.compile("@longitud").evaluate(nacimientocoord);
			p.lugarNacimientoCoord.altitud = xPath.compile("@altitud").evaluate(nacimientocoord);
			
			Node lugarResidenciaCoord = (Node) xPath.compile("coordenadasResidencia").evaluate(nodo, XPathConstants.NODE);
			p.lugarResidenciaCoord.latitud = xPath.compile("@latitud").evaluate(lugarResidenciaCoord);
			p.lugarResidenciaCoord.longitud = xPath.compile("@longitud").evaluate(lugarResidenciaCoord);
			p.lugarResidenciaCoord.altitud = xPath.compile("@altitud").evaluate(lugarResidenciaCoord);

			NodeList fotos = (NodeList) xPath.compile("foto").evaluate(nodo, XPathConstants.NODESET);
			NodeList videos = (NodeList) xPath.compile("video").evaluate(nodo, XPathConstants.NODESET);

			Node nodo2;
			for (int j = 0; j < fotos.getLength(); j++) {
				nodo2 = fotos.item(j);
				if (nodo2.getFirstChild() != null)
					p.fotos.add(nodo2.getFirstChild().getNodeValue());
			}

			for (int j = 0; j < videos.getLength(); j++) {
				nodo2 = videos.item(j);
				if (nodo2.getFirstChild() != null)
					p.videos.add(nodo2.getFirstChild().getNodeValue());
			}

			personas.add(p);
		}
	}

	private void cuerpo() {
		lineas.add("<body>");

		lineas.add("<h1>Red social</h1>");

		for (Persona p : personas) {
			lineas.add("<h2>" + p.nombre + " " + p.apellidos + "</h2>");
			lineas.add("<p>Fecha de nacimiento: " + p.fechaNacimiento + "</p>");
			lineas.add("<p>Lugar de nacimiento: " + p.lugarNacimiento + "</p>");
			lineas.add("<p>Lugar de residencia: " + p.lugarResidencia + "</p>");
			lineas.add("<p>Comentario: " + p.comentario + "</p>");

			lineas.add("<p>Coordenadas lugar de nacimiento<p>");
			p.lugarNacimientoCoord.toHTML5();
			lineas.add("<p>Coordenadas lugar de residencia<p>");
			p.lugarResidenciaCoord.toHTML5();

			for (String foto : p.fotos) {
				lineas.add("<img src=\"multimedia/" + foto + "\" alt=\"" + p.fotos + "\">");
			}

			for (String video : p.videos) {
				lineas.add("<video src=multimedia/" + video + " controls>Video</video>");
			}
		}

		lineas.add("</body>");
		lineas.add("</html>");

	}
	
	private FileUtil f = new FileUtil();

	public void escribirArchivo() {
		f.writeLines(archivoHTML5, lineas);

	}

	private List<String> lineas = new ArrayList<>();

	public class Persona {
		String nombre;
		String apellidos;
		String fechaNacimiento;
		String lugarNacimiento;
		String lugarResidencia;
		String comentario;

		Coordenadas lugarNacimientoCoord = new Coordenadas();
		Coordenadas lugarResidenciaCoord = new Coordenadas();
		List<String> fotos = new ArrayList<String>();
		List<String> videos = new ArrayList<String>();

	}

	public class Coordenadas {
		String latitud;
		String longitud;
		String altitud;

		public void toHTML5() {
			lineas.add("<ul>");
			lineas.add("<li> Longitud: " + longitud + "</li>");
			lineas.add("<li> Latitud: " + latitud + "</li>");
			lineas.add("<li> Altitud: " + altitud + "</li>");
			lineas.add("</ul>");
		}
	}
	
}
