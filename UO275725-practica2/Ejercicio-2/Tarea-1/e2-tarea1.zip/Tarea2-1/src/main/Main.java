package main;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

public class Main {
	public static void main(String[] args) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException {
		XMLtoHTML5 execute = new XMLtoHTML5("personas.xml","personas.html");
		execute.crearHTML5();
	}
}
